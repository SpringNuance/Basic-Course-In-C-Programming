int array_sum(int* array, int count);
unsigned int array_reader(int* vals, int n);
