void sort(int* start, int size);
