unsigned int arraylen(const char* array);
void countchars(const char* array, unsigned int* counts);
