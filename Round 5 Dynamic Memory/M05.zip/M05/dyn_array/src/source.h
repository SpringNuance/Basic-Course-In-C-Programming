#ifndef AALTO_CSUM14_31
#define AALTO_CSUM14_31

int* create_dyn_array(unsigned int n);
int* add_dyn_array(int* arr, unsigned int num, int newval);

#endif
