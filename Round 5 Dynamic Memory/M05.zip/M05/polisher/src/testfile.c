// This is a test file
int main(void) {
/*
 * comment
 * block
*/
printf("juu\n");
while (1)
{
// Another comment
while (2) {
printf("jaa\n");
}
}
}
