#ifndef AALTO_CLEANER_H
#define AALTO_CLEANER_H

char* delete_comments(char* input);

#endif
