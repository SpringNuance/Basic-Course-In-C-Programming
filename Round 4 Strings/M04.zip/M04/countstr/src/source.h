
int num_substr(const char* str, const char* sub);