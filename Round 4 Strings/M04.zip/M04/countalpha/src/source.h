
int count_isalpha(const char* str);