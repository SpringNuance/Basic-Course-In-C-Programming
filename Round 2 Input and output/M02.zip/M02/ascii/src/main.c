#include "source.h"

int main()
{
    ascii_chart(28,38);
    printf("\n");
    
    return 0;
}
