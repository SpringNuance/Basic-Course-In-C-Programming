#include <stdio.h>

void ascii_chart(char min, char max);
