
void simple_multiply(void);
void simple_math(void);
