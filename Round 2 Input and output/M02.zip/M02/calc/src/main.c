#include <stdio.h>
#include "source.h"

int main()
{
    printf("\n--- Testing multiply ---\n");
    simple_multiply();

    printf("\n--- Testing calculator ---\n");
    simple_math();
    
    return 0;
}
