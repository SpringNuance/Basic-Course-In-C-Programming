#include "source.h"

int main()
{
    draw_triangle(10);
    
    return 0;
}
