#include <stdio.h>

void draw_triangle(unsigned int size);
