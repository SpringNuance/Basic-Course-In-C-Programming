#include <stdio.h>

int main(void) {
    float pi = 3.14159;
    printf("The number is %f\n", pi);

    return 0;
}