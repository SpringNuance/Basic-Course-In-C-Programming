#include <stdio.h>

int main() {
    printf("January\nFebruary\nMarch\n");

    return 0;
}