**The objective of this task is to learn how to write, compile and test a program
in your own environment. After completing the following assignment, submit it here.**

Implement a program that prints three lines of the following style:

January
February
March

A new line character must be printed after printing the last row.
Output must be in the same order as the sample output given above.

Implement a program (main-function), in the file ***main.c***. Test the program
first on your local machine, and while it seems to work, return it below as an 
attachment.