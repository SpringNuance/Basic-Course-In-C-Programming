**Tämän tehtävän tavoite on oppia toteuttamaan ensimmäinen oma ohjelma,
jonka käännät ja testaat itse omassa ympäristössäsi.
Lopuksi lähetät valmiin ohjelman TIMiin.**

Toteuta ohjelma, joka  tulostaa kolme riviä seuraavaan tyyliin:

January
February
March

Myös viimeisen rivin perässä tulee olla rivinvaihto. Tulosteen on oltava
täsmälleen oikein jotta saat pisteet.

Toteuta ohjelma main-funktioon, tiedostoon *main.c*. Testaa ohjelmaa ensin
omalla koneellasi, ja kun se tuntuu toimivan, palauta se alla olevan
painikkeen kautta.