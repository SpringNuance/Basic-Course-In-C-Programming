double vectorlength(double x, double y, double z);
