#include <stdio.h>

int main(void) {
    /* The following line will print out some text */
    printf("Hey!\nHow are you?\nI am fine, thank you.\n");

    return 0;
}