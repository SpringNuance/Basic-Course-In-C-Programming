#ifndef AALTO_HEXREAD_H
#define	AALTO_HEXREAD_H

int file_to_hex(const char* filename);

#endif
