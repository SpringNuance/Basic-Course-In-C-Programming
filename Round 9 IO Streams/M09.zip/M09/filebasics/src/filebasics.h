#ifndef AALTO_FILEREAD_H
#define	AALTO_FILEREAD_H

int print_file_and_count(const char* filename);
char* difference(const char* file1, const char* file2);

#endif	/* AALTO_FILEREAD_H */
