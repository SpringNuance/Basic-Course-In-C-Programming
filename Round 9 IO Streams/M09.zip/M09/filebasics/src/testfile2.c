// This is a test file
int main(void) {
/* comment
block */
while (1)
{
// Another comment
while (2) {
printf("jaa\n");
}
}
}
