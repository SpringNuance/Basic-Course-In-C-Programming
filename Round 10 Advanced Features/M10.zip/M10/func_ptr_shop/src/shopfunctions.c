#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "shopfunctions.h"

int compareAlpha(const void* a, const void* b) {
	return strcmp(((const Product*)a)->name, ((const Product*)b)->name);
}

int compareNum(const void* a, const void* b) {
	int cmp = ((const Product*)b)->in_stock - ((const Product*)a)->in_stock;
	if(cmp != 0)
		return cmp;
	
	return compareAlpha(a, b);
}

const Product* findProduct(const Product* p_array, const char* search_key, int (*cmp)(const void*, const void*)) {
	Product p;
	strcpy(p.name, search_key);

	int n = 0;
	while(p_array[n].name[0] != 0)
		n++;

	return bsearch(&p, p_array, n, sizeof(Product), cmp);
}

