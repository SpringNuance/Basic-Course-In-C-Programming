int myprint(const char* str, ...);
