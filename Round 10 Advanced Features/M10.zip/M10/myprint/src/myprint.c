#include <stdarg.h>
#include <stdio.h>
#include <string.h>

int myprint(const char* str, ...) {
    va_list vl;

    va_start(vl, str);

    int c = 0;

    for(size_t i=0; i<strlen(str); i++) {
        if(str[i] != '&') {
            fputc(str[i], stdout);
        } else {
            printf("%d", va_arg(vl, int));
            c++;
        }
    }

    return c;
}